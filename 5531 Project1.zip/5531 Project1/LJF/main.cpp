#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <ctime>

using namespace std;

struct Process {
    int id;
    int arrivalTime;
    int burstTime;
    int waitingTime;
    int turnaroundTime;
    bool isCompleted = false;
};

void ljfScheduling(vector<Process>& processes) {
    int currentTime = 0;
    int completed = 0;
    int n = processes.size();

    while (completed != n) {
        int longestIndex = -1;
        int longestBurst = -1;

        for (int i = 0; i < n; i++) {
            if (processes[i].arrivalTime <= currentTime && !processes[i].isCompleted && processes[i].burstTime > longestBurst) {
                longestBurst = processes[i].burstTime;
                longestIndex = i;
            }
        }

        if (longestIndex != -1) {
            currentTime += processes[longestIndex].burstTime;
            processes[longestIndex].turnaroundTime = currentTime - processes[longestIndex].arrivalTime;
            processes[longestIndex].waitingTime = processes[longestIndex].turnaroundTime - processes[longestIndex].burstTime;
            processes[longestIndex].isCompleted = true;
            completed++;
        } else {
            currentTime++;
        }
    }
}

void displayResults(const vector<Process>& processes) {
    cout << "ProcessID\tArrivalTime\tBurstTime\tWaitingTime\tTurnaroundTime\n";
    for (const Process& p : processes) {
        cout << p.id << "\t\t" << p.arrivalTime << "\t\t" << p.burstTime
             << "\t\t" << p.waitingTime << "\t\t" << p.turnaroundTime << endl;
    }
}

int main() {
    srand(time(0));
    vector<Process> processes(96);
    for (int i = 0; i < 96; i++) {
        processes[i].id = i + 1;
        processes[i].arrivalTime = rand() % 50;
        processes[i].burstTime = rand() % 20 + 1;
    }

    ljfScheduling(processes);
    displayResults(processes);

    return 0;
}
