#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <ctime>
using namespace std;

struct Process {
    int id;
    int arrivalTime;
    int burstTime;
    int waitingTime = 0;
    int turnaroundTime = 0;
    bool isCompleted = false;
};

double calculateResponseRatio(const Process& process, int currentTime) {
    int waitingTime = currentTime - process.arrivalTime;
    return (double)(waitingTime + process.burstTime) / process.burstTime;
}

void hrrnScheduling(vector<Process>& processes) {
    int currentTime = 0;
    int completed = 0;
    int n = processes.size();

    while (completed != n) {
        int hrrnIndex = -1;
        double highestResponseRatio = -1.0;

        for (int i = 0; i < n; i++) {
            if (processes[i].arrivalTime <= currentTime && !processes[i].isCompleted) {
                double responseRatio = calculateResponseRatio(processes[i], currentTime);
                if (responseRatio > highestResponseRatio) {
                    highestResponseRatio = responseRatio;
                    hrrnIndex = i;
                }
            }
        }

        if (hrrnIndex != -1) {
            currentTime += processes[hrrnIndex].burstTime;
            processes[hrrnIndex].turnaroundTime = currentTime - processes[hrrnIndex].arrivalTime;
            processes[hrrnIndex].waitingTime = processes[hrrnIndex].turnaroundTime - processes[hrrnIndex].burstTime;
            processes[hrrnIndex].isCompleted = true;
            completed++;
        } else {
            currentTime++;
        }
    }
}

void displayResults(const vector<Process>& processes) {
    cout << "ProcessID\tArrivalTime\tBurstTime\tWaitingTime\tTurnaroundTime\n";
    for (const Process& p : processes) {
        cout << p.id << "\t\t" << p.arrivalTime << "\t\t" << p.burstTime
             << "\t\t" << p.waitingTime << "\t\t" << p.turnaroundTime << endl;
    }
}

int main() {
    srand(time(0));

    vector<Process> processes(96);
    for (int i = 0; i < 96; i++) {
        processes[i].id = i + 1;
        processes[i].arrivalTime = rand() % 50;
        processes[i].burstTime = rand() % 20 + 1;
    }

    hrrnScheduling(processes);
    displayResults(processes);

    return 0;
}
