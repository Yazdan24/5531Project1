#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <ctime>

using namespace std;

struct Process {
    int id;
    int arrivalTime;
    int burstTime;
    int remainingTime;
    int waitingTime = 0;
    int turnaroundTime = 0;
};

void srtfScheduling(vector<Process>& processes) {
    int currentTime = 0;
    int completed = 0;
    int n = processes.size();

    while (completed != n) {
        int shortestIndex = -1;
        int shortestTime = 999999;

        for (int i = 0; i < n; i++) {
            if (processes[i].arrivalTime <= currentTime && processes[i].remainingTime > 0 && processes[i].remainingTime < shortestTime) {
                shortestTime = processes[i].remainingTime;
                shortestIndex = i;
            }
        }

        if (shortestIndex != -1) {
            currentTime++;
            processes[shortestIndex].remainingTime--;

            if (processes[shortestIndex].remainingTime == 0) {
                processes[shortestIndex].turnaroundTime = currentTime - processes[shortestIndex].arrivalTime;
                processes[shortestIndex].waitingTime = processes[shortestIndex].turnaroundTime - processes[shortestIndex].burstTime;
                completed++;
            }
        } else {
            currentTime++;
        }
    }
}

void displayResults(const vector<Process>& processes) {
    cout << "ProcessID\tArrivalTime\tBurstTime\tWaitingTime\tTurnaroundTime\n";
    for (const Process& p : processes) {
        cout << p.id << "\t\t" << p.arrivalTime << "\t\t" << p.burstTime
             << "\t\t" << p.waitingTime << "\t\t" << p.turnaroundTime << endl;
    }
}

int main() {
    srand(time(0));

    vector<Process> processes(96);
    for (int i = 0; i < 96; i++) {
        processes[i].id = i + 1;
        processes[i].arrivalTime = rand() % 50;
        processes[i].burstTime = rand() % 20 + 1;
        processes[i].remainingTime = processes[i].burstTime;
    }

    srtfScheduling(processes);
    displayResults(processes);

    return 0;
}
